<img src="assets/hero.svg" width="100%" alt="Molly Arora, AI/ML engineer building voice agents and LLM systems">

<p align="center">
  <a href="https://molly-portfolio-three.vercel.app/"><img src="https://img.shields.io/badge/Portfolio-molly--portfolio--three.vercel.app-24507A?style=flat-square&labelColor=0F1B2D" alt="Portfolio"></a>
  <a href="https://www.linkedin.com/in/molly-arora-20b11124a/"><img src="https://img.shields.io/badge/LinkedIn-Molly_Arora-24507A?style=flat-square&labelColor=0F1B2D&logo=linkedin&logoColor=white" alt="LinkedIn"></a>
  <a href="mailto:aroramolly180@gmail.com"><img src="https://img.shields.io/badge/Email-aroramolly180%40gmail.com-24507A?style=flat-square&labelColor=0F1B2D&logo=gmail&logoColor=white" alt="Email"></a>
</p>

<img src="assets/title-about.svg" width="100%" alt="About">

I'm a B.Tech Computer Science (AI) student at **Mirai School of Technology × Hi-Tech Institute of Engineering and Technology**, with a **Data Science and ML minor from IIT Mandi (8.0 CGPA)**.

I design LLM and agent pipelines and real-time voice AI systems, and take them to production. MUSE AI, my voice agent, is live and published on Agora's Voice AI Recipes platform. I'm looking for a **Student Researcher role in applied AI** (remote, India).

<img src="assets/title-recognition.svg" width="100%" alt="Recognition">
<img src="assets/proof.svg" width="100%" alt="Live and published on Agora's Voice AI Recipes; 8th PAN India at DevSummit 2026; 2nd Runner-Up at Hacktoberfest x SAU">

Coursework: **Prompt Engineering** (Google, via Coursera), **Code in Place** (Stanford, Python), **Data Science and ML minor** (IIT Mandi).

<img src="assets/title-work.svg" width="100%" alt="Selected work">

<a href="https://thoughtworks-eight.vercel.app"><img src="assets/project-muse.svg" width="100%" alt="MUSE AI: live voice AI music co-producer built on Agora, published on Agora's Voice AI Recipes platform"></a>
<p align="center">
  <a href="https://thoughtworks-eight.vercel.app"><img src="https://img.shields.io/badge/Live_demo-MUSE_AI-24507A?style=flat-square&labelColor=0F1B2D" alt="MUSE AI live demo"></a>
  <a href="https://recipes.agora.io/recipes/muse-ai"><img src="https://img.shields.io/badge/Agora_recipe-MUSE_AI-24507A?style=flat-square&labelColor=0F1B2D" alt="MUSE AI on Agora Recipes"></a>
  <a href="https://github.com/Molly-Arora02/MUSE-AI-"><img src="https://img.shields.io/badge/Code-MUSE--AI-24507A?style=flat-square&labelColor=0F1B2D&logo=github&logoColor=white" alt="MUSE AI repository"></a>
</p>

<img src="assets/muse-architecture.svg" width="100%" alt="MUSE AI architecture: browser microphone, Agora RTC channel, conversational AI agent, persona reply, with pitch detection, Web Audio sandbox and live prompt injection">

<!-- TODO: add the Phantom Mesh repo/demo link on the card below, e.g. wrap the <img> in <a href="YOUR_URL"> -->
<img src="assets/project-phantom.svg" width="100%" alt="Phantom Mesh: real-time AI voice assistant for spam and scam calls, ranked 8th PAN India at DevSummit 2026">

<a href="https://citysaathi-gamma.vercel.app"><img src="assets/project-citysaathi.svg" width="100%" alt="CitySaathi: AI travel guide for local transport, 2nd Runner-Up at Hacktoberfest x SAU"></a>
<p align="center">
  <a href="https://citysaathi-gamma.vercel.app"><img src="https://img.shields.io/badge/Live_demo-CitySaathi-24507A?style=flat-square&labelColor=0F1B2D" alt="CitySaathi live demo"></a>
</p>

<!-- TODO: add the Satyadarshi repo/demo link on the card below -->
<img src="assets/project-satyadarshi.svg" width="100%" alt="Satyadarshi: AI-proctored exam platform">

<a href="https://focus-forge-eight-zeta.vercel.app"><img src="assets/project-focusforge.svg" width="100%" alt="Focus Forge: AI study environment, prototype in progress"></a>
<p align="center">
  <a href="https://focus-forge-eight-zeta.vercel.app"><img src="https://img.shields.io/badge/Live_demo-Focus_Forge-24507A?style=flat-square&labelColor=0F1B2D" alt="Focus Forge live demo"></a>
  <a href="https://github.com/Molly-Arora02/FOCUS-FORGE_"><img src="https://img.shields.io/badge/Code-Focus_Forge-24507A?style=flat-square&labelColor=0F1B2D&logo=github&logoColor=white" alt="Focus Forge repository"></a>
</p>

<img src="assets/title-domains.svg" width="100%" alt="Domains">

| Domain | Skills | Evidence |
| :-- | :-- | :-- |
| **Voice and real-time AI** | Agora RTC SDK, Agora Conversational AI, Web Audio API, live prompt injection, AI personas | MUSE AI (live, on Agora Recipes), Phantom Mesh (8th PAN India) |
| **LLM apps and agents** | LLM and agent pipeline design, prompt engineering, Anthropic Python SDK, Next.js, Supabase Auth, MongoDB | CitySaathi (2nd Runner-Up), Focus Forge (prototype) |
| **AI for trust and integrity** | Exam proctoring, camera, screen and audio streaming, copied and AI-generated answer flagging, scam-call handling | Satyadarshi, Phantom Mesh |
| **Full-stack engineering** | React, TypeScript, JavaScript, REST APIs, Android, Git and GitHub | Coding Blocks intern (Jun–Aug 2026), InternsElite (Jan–Mar 2025), GSSoC 2026 |
| **ML and data foundations** | Python, C++, data structures and algorithms, Google Colab | IIT Mandi Data Science and ML minor (8.0 CGPA), Stanford Code in Place |
| **Community and leadership** | Event and digital marketing, sponsorships, stakeholder coordination | Head of Social Media and Marketing, Nex-Cell (Sep 2025 – present); Campus Ambassador, E-Cell IIT Bombay |

<img src="assets/title-toolkit.svg" width="100%" alt="Toolkit">

<p align="center">
  <img src="https://skillicons.dev/icons?i=python,cpp,ts,js,react,nextjs,tailwind,vite,mongodb,supabase,git,github,vercel,androidstudio&perline=7&theme=dark" alt="Python, C++, TypeScript, JavaScript, React, Next.js, Tailwind CSS, Vite, MongoDB, Supabase, Git, GitHub, Vercel, Android Studio">
</p>

<img src="assets/title-connect.svg" width="100%" alt="Connect">

<p align="center">
  <a href="https://molly-portfolio-three.vercel.app/"><img src="https://img.shields.io/badge/Portfolio-molly--portfolio--three.vercel.app-24507A?style=flat-square&labelColor=0F1B2D" alt="Portfolio"></a>
  <a href="https://www.linkedin.com/in/molly-arora-20b11124a/"><img src="https://img.shields.io/badge/LinkedIn-24507A?style=flat-square&labelColor=0F1B2D&logo=linkedin&logoColor=white" alt="LinkedIn"></a>
  <a href="mailto:aroramolly180@gmail.com"><img src="https://img.shields.io/badge/Email-24507A?style=flat-square&labelColor=0F1B2D&logo=gmail&logoColor=white" alt="Email"></a>
</p>

<img src="assets/footer.svg" width="100%" alt="Applied AI: voice systems and LLM pipelines">
